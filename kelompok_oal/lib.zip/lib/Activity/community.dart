import 'package:flutter/material.dart';

class MyCommunity extends StatefulWidget {
  const MyCommunity({super.key});

  @override
  State<MyCommunity> createState() => _MyCommunityState();
}

class _MyCommunityState extends State<MyCommunity> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            toolbarHeight: 200,
            title: Padding(
              padding: const EdgeInsets.only(
                top: 2,
              ),
              child: Column(
                children: [
                  const Text('Profile'),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    child: Row(
                      children: [
                        Expanded(
                          flex: 3,
                          child: Container(
                            margin: const EdgeInsets.only(top: 15, left: 15),
                            height: 100,
                            decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                    image: AssetImage(
                                        'assets/images/profile.jpeg'))),
                          ),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        const Expanded(
                            flex: 6,
                            child: Text(
                              'Ferdinan',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 25),
                            )),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            bottom: TabBar(tabs: [
              Tab(text: 'Course Progress'),
              Tab(
                text: 'Course Selesai',
              )
            ]),
          ),
          body: TabBarView(children: [
            Container(
              color: Colors.green,
            ),
            Container(
              color: Colors.red,
            ),
          ]),
        ));
  }
}
