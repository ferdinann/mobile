import 'package:flutter/material.dart';
import 'package:kelompok_oal/Activity/dropDown.dart';
import 'package:kelompok_oal/Activity/home.dart';
import 'package:kelompok_oal/Activity/test.dart';

class MyProfile extends StatefulWidget {
  const MyProfile({super.key});

  @override
  State<MyProfile> createState() => _MyProfileState();
}

class _MyProfileState extends State<MyProfile> {
  final dropdown = const [MyProfileData(), MyProgress()];
  var ddB = null;
  // var ddB = "My Profile";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Profile'),
        ),
        body: ListView(
          children: [
            Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  child: Row(
                    children: [
                      Expanded(
                        flex: 3,
                        child: Container(
                          margin: const EdgeInsets.only(top: 15, left: 15),
                          height: 100,
                          decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              image: DecorationImage(
                                  image: AssetImage(
                                      'assets/images/profile.jpeg'))),
                        ),
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      const Expanded(
                          flex: 6,
                          child: Text(
                            'Ferdinan',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 25),
                          )),
                    ],
                  ),
                ),
                Row(
                  children: [
                    Padding(padding: EdgeInsets.only(left: 20, bottom: 100)),
                    DropdownButton(
                      borderRadius: BorderRadius.circular(10),
                      padding: EdgeInsets.all(8),
                      dropdownColor: Colors.blue[50],
                      value: ddB,
                      hint: const Text("Navigasi Profile"),
                      items: const [
                        DropdownMenuItem(
                          value: "My Profile",
                          child: Text(
                            'My Profile',
                            style: TextStyle(color: Colors.blue),
                          ),
                        ),
                        DropdownMenuItem(
                          value: "Activity",
                          child: Text('Activity',
                              style: TextStyle(color: Colors.blue)),
                        ),
                      ],
                      onChanged: (value) {
                        setState(() {
                          ddB = value!;
                        });
                      },
                    ),
                  ],
                ),
              ],
            ),
            ddB == null
                ? dropdown[0]
                : ddB == "My Profile"
                    ? dropdown[0]
                    : ddB == "Activity"
                        ? dropdown[1]
                        : dropdown[1]
          ],
        ));
  }
}

class MyProfileData extends StatefulWidget {
  const MyProfileData({super.key});

  @override
  State<MyProfileData> createState() => _MyProfileDataState();
}

class _MyProfileDataState extends State<MyProfileData> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: TextField(
            controller: TextEditingController(text: 'Ferdinanta Ginting'),
            decoration: InputDecoration(
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                hintText: 'Nama',
                label: const Text('Nama lengkap')),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              Expanded(
                flex: 5,
                child: TextField(
                  controller: TextEditingController(text: '28/05/2004'),
                  keyboardType: TextInputType.datetime,
                  decoration: InputDecoration(
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      hintText: 'Tanggal Lahir',
                      suffix: const Icon(Icons.date_range_rounded),
                      label: const Text('Tanggal Lahir')),
                ),
              ),
              const SizedBox(
                width: 8,
              ),
              Expanded(
                flex: 5,
                child: TextField(
                  controller: TextEditingController(text: 'Laki-laki'),
                  decoration: InputDecoration(
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      hintText: 'Gender',
                      label: const Text('Gender')),
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: TextField(
            controller: TextEditingController(text: '083166896713'),
            keyboardType: TextInputType.phone,
            decoration: InputDecoration(
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                hintText: 'No.Hp',
                label: const Text('No.HP')),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: TextField(
            controller: TextEditingController(text: 'Deli Serdang'),
            decoration: InputDecoration(
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                hintText: 'Kab/kota',
                label: const Text('Domisili')),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: TextField(
            controller: TextEditingController(text: 'Mahasiswa'),
            decoration: InputDecoration(
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                hintText: 'Profesi',
                label: const Text('Profesi')),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(35.0),
          child: ElevatedButton(
              style: ButtonStyle(
                  shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)))),
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => const MyHome()));
              },
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  'Save',
                  style: TextStyle(fontSize: 20),
                ),
              )),
        ),
      ],
    );
  }
}

class MyProgress extends StatefulWidget {
  const MyProgress({super.key});

  @override
  State<MyProgress> createState() => _MyProgressState();
}

class _MyProgressState extends State<MyProgress> {
  Color courseProgresColor = Colors.blue;
  Color courseSelesaiColor = Colors.black;
  var ghj = [MyCourseProgres(), MyCyber()];

  void updateButtonState(int index) {
    setState(() {
      courseProgresColor = index == 0 ? Colors.blue : Colors.black;
      courseSelesaiColor = index == 1 ? Colors.blue : Colors.black;
    });
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
        length: 2,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 10),
              // child: Row(
              //   children: [
              //     TextButton(
              //         onPressed: () => updateButtonState(0),
              //         child: Text(
              //           "Course Progress",
              //           style: TextStyle(
              //               fontSize: 17,
              //               fontWeight: FontWeight.bold,
              //               fontFamily: AutofillHints.givenName,
              //               color: courseProgresColor),
              //         )),
              //     TextButton(
              //         onPressed: () => {updateButtonState(1)},
              //         child: Text(
              //           "Course Selesai",
              //           style: TextStyle(
              //               fontSize: 17,
              //               fontWeight: FontWeight.bold,
              //               fontFamily: AutofillHints.givenName,
              //               color: courseSelesaiColor),
              //         ))
              //   ],
              // ),
            ),
          ],
        ));
  }
}

class MyCourseProgres extends StatefulWidget {
  const MyCourseProgres({super.key});

  @override
  State<MyCourseProgres> createState() => _MyCourseProgresState();
}

class _MyCourseProgresState extends State<MyCourseProgres> {
  Map<String, double> learningProgress = {
    'Data Science': 50.0, // contoh persentase jalan belajar untuk Data Science
    'Mobile Developer':
        30.0, // contoh persentase jalan belajar untuk Mobile Developer
  };
  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
      InkWell(
        onTap: () {
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => MyTest()));
        },
        child: Padding(
          padding: const EdgeInsets.only(left: 40, right: 40),
          child: Card(
            color: Colors.white,
            shadowColor: Colors.grey,
            margin: EdgeInsets.all(20),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image(
                    image: AssetImage('assets/images/data.jpeg'),
                    height: 130,
                    width: 200,
                  ),
                  Text(
                    'Data Science',
                    style: TextStyle(color: Colors.black),
                  ),
                  SizedBox(height: 10),
                  // Tampilkan bar persentase jalan belajar
                  LinearProgressIndicator(
                    value: learningProgress['Data Science']! / 100,
                    backgroundColor: Colors.grey[300],
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.blue),
                  ),
                  SizedBox(height: 5),
                  Text(
                    '${learningProgress['Data Science']}% Complete',
                    style: TextStyle(color: Colors.black),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      GestureDetector(
        onTap: () {
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => MyTest()));
        },
        child: Padding(
          padding: const EdgeInsets.only(left: 40, right: 40),
          child: Card(
            color: Colors.white,
            shadowColor: Colors.grey,
            margin: EdgeInsets.all(20),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image(
                    image: AssetImage('assets/images/mobile.jpeg'),
                    height: 130,
                    width: 200,
                  ),
                  Text(
                    'Mobile Developer',
                    style: TextStyle(color: Colors.black),
                  ),
                  SizedBox(height: 10),
                  // Tampilkan bar persentase jalan belajar
                  LinearProgressIndicator(
                    value: learningProgress['Mobile Developer']! / 100,
                    backgroundColor: Colors.grey[300],
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.blue),
                  ),
                  SizedBox(height: 5),
                  Text(
                    '${learningProgress['Mobile Developer']}% Complete',
                    style: TextStyle(color: Colors.black),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    ]);
  }
}
